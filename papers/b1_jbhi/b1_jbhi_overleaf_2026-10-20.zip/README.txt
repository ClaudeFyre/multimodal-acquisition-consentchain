Overleaf package: Stage Before Sequencing (IEEE JBHI manuscript, v2, 2026-10-20)

Upload: Overleaf > New Project > Upload Project > select this zip. Compiler: pdfLaTeX. Main document: main.tex.
All packages are in TeX Live (IEEEtran, soul, tcolorbox, booktabs, xcolor, hyperref, array).

Blockchain highlighting: amber highlights and boxes mark blockchain components that are specified as
software interfaces but NOT evaluated in this study. To remove the highlighting for the submission
version, uncomment this line near the top of main.tex:
  % \chainhlfalse

Red [TODO] marks still to fill: author list and affiliations, data-use statement, repository URL.
References marked "verify" in refs.bib (covert2023, azaria2016, androulaki2018) were written from memory.
Figures are vector PDFs produced by make_figures.py from the frozen experiment outputs.
